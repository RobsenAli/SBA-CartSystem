package com.example;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map;

public class AppSystem extends TheSystem {
	// public Item newItem = new Item();

	AppSystem() {

	}

	@Override
	public void display() {

		// Your code here
		System.out.println("AppSystem Inventory:");

		System.out.printf("%-20s %-20s %-10s %-10s\n", "Name", "Description", "Price", "Available Quantity");

		Iterator displayIterator = super.getItemCollection().entrySet().iterator();

		while (displayIterator.hasNext()) {

			Map.Entry el = (Map.Entry) displayIterator.next();

			Item dispMethod = super.getItemCollection().get(el.getKey());
			System.out.printf("%-20s %-20s %-10s %-10s\n", dispMethod.getItemName(), dispMethod.getItemDesc(),
					String.format("%.2f", dispMethod.getItemPrice()), dispMethod.getAvailableQuantity());

		}

	}

	@Override // this overwrites the parents class add method
	public Boolean add(Item item) {
		// Your code here
		if (item == null) {
			return false;
		} else if (super.getItemCollection().containsKey(item.getItemName())) {
			Item it = super.getItemCollection().get(item.getItemName());
			it.setAvailableQuantity(it.getAvailableQuantity() + 1);
			System.out.printf("%s is already in the App System", item.getItemName());
			return false;
		} else if (!super.getItemCollection().containsKey(item.getItemName())) {
			super.getItemCollection().put(item.getItemName(), item);
			return true;
		} else {
			return null;
		}
	}

	public Item reduceAvailableQuantity(String item_name) {
		if (!getItemCollection().containsKey(item_name)) {
			System.out.printf("%s is not in the App System\n", item_name);
			return null;
		}
		Item item = getItemCollection().get(item_name);
		item.setAvailableQuantity(item.getAvailableQuantity() - 1);
		if (item.getAvailableQuantity() < 1) {
			this.remove(item_name);
			return null;
		}
		return item;
	}
}
