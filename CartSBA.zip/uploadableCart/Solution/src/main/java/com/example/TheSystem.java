package com.example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public abstract class TheSystem {

    private HashMap<String, Item> itemCollection;

    TheSystem() {
        super();
        // Your code here
        
        



        this.itemCollection = new HashMap<String, Item>();
        
        

         if (getClass().getSimpleName().equals("AppSystem")) {
//            System.out.println("Were inside App System");


            try {
                
                String file_path = "resources//sample.txt";
                String line = "";
                BufferedReader br = new BufferedReader(new FileReader(file_path));
                

                while((line = br.readLine()) != null) {
                    
                    
                    String[] values = line.split("  ");
                    Item temp = new Item(values[0], values[1], Double.parseDouble(values[2]), Integer.parseInt(values[3]));
                    String data = values[0];
                    this.itemCollection.put(data, temp);
                    


//                    System.out.println(Arrays.toString(values));
                }
            } catch (FileNotFoundException e) {
                System.out.println("An error occured");
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            
            
        }
    }

    public HashMap<String, Item> getItemCollection() {
        return itemCollection;
        // Your code here
    }

    public Boolean checkAvailability(Item item) {
        
        if (item.getQuantity() >= item.getAvailableQuantity()) {
            System.out.println("System is unable to add " + item.getItemName() +
                    " to the card. System only has " + item.getAvailableQuantity() + item.getItemName());
            return false;
        } else {
            return true;
        }
        
    }

public Boolean add(Item item) {
        if (item == null) {                    // 1
            return false;
        } else if (this.itemCollection.containsKey(item.getItemName())) {        // 2
             Item orgItem = itemCollection.get(item.getItemName());
             orgItem.setQuantity(orgItem.getQuantity()+1); // increasing shopping cart
             System.out.println("true");
            return true;
        } else {
            this.itemCollection.put(item.getItemName(), item);
            return true;
        }
                     
        
    }
    
  public Item remove(String itemName) {
    
        // Your code here
        if (this.itemCollection.containsKey(itemName)) {
                return this.itemCollection.remove(itemName);

        }
            return null;
    }

    public abstract void display();

    public void setItemCollection(HashMap<String, Item> itemCollection) {
        this.itemCollection = itemCollection;
    }
}