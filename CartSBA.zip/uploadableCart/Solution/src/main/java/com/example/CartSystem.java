package com.example;

public class CartSystem extends TheSystem {
    public double subTotal;
    CartSystem() {
        super();
    }

    @Override
    public void display() {
        
        if (getItemCollection() == null) {
            System.out.println("No items in list");
        }
             
        System.out.println("Cart:");
        System.out.printf("%-20s %-20s %-10s %-10s %-10s\n", "Name", "Description", "Price", "Quantity", "Sub Total" );

        
        // Your code here
        for (String i: this.getItemCollection().keySet()) {
            int quantity = this.getItemCollection().get(i).getQuantity()+ 1;
            
        
              // increasing shopping cart
            System.out.println("Cart");
            System.out.printf("\nName: %-20s", i);
            System.out.printf("\nDescription: %-20s", this.getItemCollection().get(i).getItemDesc());
            System.out.printf("\nPrice: %-10.2f", this.getItemCollection().get(i).getItemPrice()* quantity);
            System.out.printf("\nQuantity: %-10d", quantity);

            
            
            
            subTotal += this.getItemCollection().get(i).getSubtotal();
        }
        
         double total = ((subTotal * .05) + subTotal);
         
        System.out.printf("%-20s %-20.2f\n", "Pre-tax Total", subTotal);
        System.out.printf("%-20s %-20.2f\n", "Tax", (subTotal * .05));
        System.out.printf("%-20s %-20.2f\n", "Total", total);

        
    }
}
